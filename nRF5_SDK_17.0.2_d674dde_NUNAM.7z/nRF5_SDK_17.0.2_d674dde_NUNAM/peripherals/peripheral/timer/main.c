/* NUNAM Task. 21-09-2020.
 * Application : Timer application to generate events evey Xus.
 *
 * Requirements:
 * 1. Needed a function to start the timer. Args: 1. microseconds and 2. Callback function.
 * 2. Stop function to stop the periodic event generation.
 *
 *
 *
 *
 */

/*****************************Module headers************************************/
#include <stdbool.h>
#include <stdint.h>
#include "nrf.h"
#include "nrf_drv_timer.h"
#include "bsp.h"
#include "app_error.h"

/*****************************Module Prototypes************************************/
void start_timer(uint32_t, (void*)(void));
void stop_timer(void);

/*****************************Module Macros************************************/
#define TICKS_FOR_509MS 31812

/*****************************Module Globals************************************/
uint32_t time_ticks;
uint32_t counter=0;
const nrf_drv_timer_t TIMER0 = NRF_DRV_TIMER_INSTANCE(0);

/**
 * @brief Handler for timer events.
 */
void timer_led_event_handler(nrf_timer_event_t event_type, void* p_context)
{

    switch (event_type)
    {
        case NRF_TIMER_EVENT_COMPARE0:
            printf("Count - %d", counter);
            // Increment the counter here since the event is detected.
            counter++;
            break;

        default:
            //Do nothing.
            break;
    }
}


/**
 * @brief Function for main application entry.
 */
int main(void)
{
    uint32_t ret_code = NRF_SUCCESS;

    // Configuring the timer peripheral here.
    nrf_drv_timer_config_t timer_cfg = NRF_DRV_TIMER_DEFAULT_CONFIG;

    // Invoking the timer init API.
    ret_code = nrf_drv_timer_init(&TIMER_LED, &timer_cfg, timer_led_event_handler);

    if(NRF_SUCCESS != ret_code)
    {
       // Need to invoke a error handler here if init is not succesful.
    }

    start_timer();
 
    while(1)
    {
       // Application Logic : To print the counter value which increments every 509ms
       // Trigger timer to generate 509ms base. To generate 509ms base with default conditions i.e. 16MHz input to timer 
       // We require TICKS_FOR_509MS ticks.
       nrfx_timer_compare(&TIMER0, NRF_TIMER_CC_CHANNEL0, TICKS_FOR_509MS, TRUE);
    }

}

// API to start the timer.
void start_timer(uint32_t microseconds, void (*functionPtr)(void))
{
   time_ticks = nrf_drv_timer_ms_to_ticks(&TIMER0, microseconds);
   // triggering the start bit in this API to stop TIMER0.
   nrf_drv_timer_enable(&TIMER0);
}

// API to stop the timer.
void stop_timer()
{
 // triggering the stop bit in this API to stop TIMER0.
  nrf_drv_timer_disable(&TIMER0);
}

/** @} */
